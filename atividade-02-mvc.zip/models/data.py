herois = {
    "dano": [
        {"nome": "Tracer"},
        {"nome": "Genji"},
        {"nome": "Soldier 76"}
    ],
    "suporte": [
        {"nome": "Mercy"},
        {"nome": "Ana"},
        {"nome": "Lucio"}
    ],
    "tanque": [
        {"nome": "Reinhardt"},
        {"nome": "Winston"},
        {"nome": "Orisa"}
    ]
}
