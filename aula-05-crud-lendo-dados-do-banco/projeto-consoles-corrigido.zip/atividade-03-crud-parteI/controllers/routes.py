# Importando o render_template
from flask import render_template, request, redirect, url_for

from models.database import Game, Console, db

def init_app(app):

    listaGames = [{"titulo": "CS-GO", "ano": 2012, "categoria": "FPS Online"}]

    @app.route('/')
    def home():
        return render_template('index.html')

    @app.route('/games')
    def games():
        titulo = "Silk Song"
        ano = 2025
        categoria = "Metroid Van"

        game = {
            "Título": "Minecraft",
            "Ano": 2012,
            "Categoria": "Sandbox"
        }

        jogadores = ['Eduardo', 'Ana', 'Guilherme', 'Vitor', 'Antônio']

        return render_template('games.html', titulo=titulo, ano=ano, categoria=categoria, jogadores=jogadores, game=game)

    @app.route('/consoles')
    def consoles():
        consoles = ['Xbox', 'Playstation 5', 'Super Nintendo', 'Gameboy', 'Atari']
        return render_template('consoles.html', consoles=consoles)

    @app.route('/cadgames', methods=['GET', 'POST'])
    def cadgames():
        if request.method == 'POST':
            listaGames.append({'titulo': request.form.get('titulo'), 'ano': request.form.get('ano'), 'categoria': request.form.get('categoria')})
            return redirect(url_for('cadgames'))

        return render_template('cadgames.html', listaGames=listaGames)

    @app.route("/estoque-jogos", methods=['GET', 'POST'])
    def estoque_jogos():

        if request.method == 'POST':
            dados_form = request.form.to_dict()

            newGame = Game(
                dados_form['titulo'],
                dados_form['ano'],
                dados_form['categoria'],
                dados_form['plataforma'],
                dados_form['preco'],
                dados_form['quantidade']
            )

            db.session.add(newGame)
            db.session.commit()

            return redirect(url_for('estoque_jogos'))

        games = Game.query.all()

        return render_template('estoque-jogos.html', games=games)

    @app.route("/estoque-consoles", methods=['GET', 'POST'])
    def estoque_consoles():

        if request.method == 'POST':
            dados_form = request.form.to_dict()

            newConsole = Console(
                dados_form['nome'],
                dados_form['fabricante'],
                dados_form['ano'],
                dados_form['preco'],
                dados_form['quantidade']
            )

            db.session.add(newConsole)
            db.session.commit()

            return redirect(url_for('estoque_consoles'))

        consoles = Console.query.all()

        return render_template('estoque-consoles.html', consoles=consoles)
