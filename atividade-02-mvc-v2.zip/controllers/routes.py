from flask import render_template
from models.data import herois

def init_app(app):

    @app.route('/')
    def index():
        return render_template('index.html')

    @app.route('/dano')
    def dano():
        return render_template('dano.html', herois=herois["dano"])

    @app.route('/suportes')
    def suportes():
        return render_template('suportes.html', herois=herois["suporte"])

    @app.route('/tanques')
    def tanques():
        return render_template('tanques.html', herois=herois["tanque"])

    @app.route('/registro')
    def registro():
        return render_template('registro.html')
